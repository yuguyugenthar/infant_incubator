/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BABY_SENSOR_Pin GPIO_PIN_0
#define BABY_SENSOR_GPIO_Port GPIOA
#define AIR_SENSOR_Pin GPIO_PIN_1
#define AIR_SENSOR_GPIO_Port GPIOA
#define INCREASE_BTN_Pin GPIO_PIN_2
#define INCREASE_BTN_GPIO_Port GPIOA
#define DECREASE_BTN_Pin GPIO_PIN_3
#define DECREASE_BTN_GPIO_Port GPIOA
#define MODE_BTN_Pin GPIO_PIN_4
#define MODE_BTN_GPIO_Port GPIOA
#define APGAR_TIMER_BTN_Pin GPIO_PIN_5
#define APGAR_TIMER_BTN_GPIO_Port GPIOA
#define MUTE_BTN_Pin GPIO_PIN_6
#define MUTE_BTN_GPIO_Port GPIOA
#define LOCK_BTN_Pin GPIO_PIN_7
#define LOCK_BTN_GPIO_Port GPIOA
#define FERN_CONVERT_BTN_Pin GPIO_PIN_0
#define FERN_CONVERT_BTN_GPIO_Port GPIOB
#define BABY_MODE_LED_Pin GPIO_PIN_1
#define BABY_MODE_LED_GPIO_Port GPIOB
#define AIR_MODE_LED_Pin GPIO_PIN_2
#define AIR_MODE_LED_GPIO_Port GPIOB
#define PREWARM_MODE_LED_Pin GPIO_PIN_12
#define PREWARM_MODE_LED_GPIO_Port GPIOB
#define MANUAL_MODE_LED_Pin GPIO_PIN_13
#define MANUAL_MODE_LED_GPIO_Port GPIOB
#define TIMER_ON_LED_Pin GPIO_PIN_14
#define TIMER_ON_LED_GPIO_Port GPIOB
#define ALARM_LED_Pin GPIO_PIN_15
#define ALARM_LED_GPIO_Port GPIOB
#define KEY_LOCK_LED_Pin GPIO_PIN_8
#define KEY_LOCK_LED_GPIO_Port GPIOA
#define POWER_FAIL_LED_Pin GPIO_PIN_9
#define POWER_FAIL_LED_GPIO_Port GPIOA
#define HEATER_FAIL_LED_Pin GPIO_PIN_10
#define HEATER_FAIL_LED_GPIO_Port GPIOA
#define HI_TEMP_LED_Pin GPIO_PIN_15
#define HI_TEMP_LED_GPIO_Port GPIOA
#define BABY_SENSOR_LED_Pin GPIO_PIN_3
#define BABY_SENSOR_LED_GPIO_Port GPIOB
#define AIR_SENSOR_LED_Pin GPIO_PIN_4
#define AIR_SENSOR_LED_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
