uint16_t skin_Sensor=0;
uint16_t air_Sensor=0;
uint8_t timercount=0;
uint16_t previoustime=0;
uint16_t babyMode_setTemp=0;
uint16_t airMode_setTemp=0;
uint16_t setHeater_value=0;




